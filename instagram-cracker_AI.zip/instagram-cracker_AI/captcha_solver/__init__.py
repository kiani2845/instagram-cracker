from .main import capcha_solver
from .audio_to_text import audio2text